package com.example.qr_id_student_information;

class IsExist {
    private Boolean success;

    public IsExist(Boolean success) {
        this.success = success;
    }

    public Boolean getSuccess() {
        return success;
    }

    public void setSuccess(Boolean success) {
        this.success = success;
    }
}
