package com.example.qr_id_student_information;

class studentconst {

    private String usn;
    private String name	;
    private String email;
    private String mno;
    private String semester;
    private String department;
    private String postal_address;
    private String parents_mno;
    private String profile_pdf;
    private  String cgp_status;

    public studentconst(String usn, String name, String email, String mno, String semester, String department, String postal_address, String parents_mno, String profile_pdf,String cgp_status) {
        this.usn = usn;
        this.name = name;
        this.email = email;
        this.mno = mno;
        this.semester = semester;
        this.department = department;
        this.postal_address = postal_address;
        this.parents_mno = parents_mno;
        this.profile_pdf = profile_pdf;
        this.cgp_status = cgp_status;

    }

    public String getUsn() {
        return usn;
    }

    public void setUsn(String usn) {
        this.usn = usn;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getMno() {
        return mno;
    }

    public void setMno(String mno) {
        this.mno = mno;
    }

    public String getSemester() {
        return semester;
    }

    public void setSemester(String semester) {
        this.semester = semester;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public String getPostal_address() {
        return postal_address;
    }

    public void setPostal_address(String postal_address) {
        this.postal_address = postal_address;
    }

    public String getParents_mno() {
        return parents_mno;
    }

    public void setParents_mno(String parents_mno) {
        this.parents_mno = parents_mno;
    }

    public String getProfile_pdf() {
        return profile_pdf;
    }

    public void setProfile_pdf(String profile_pdf) {
        this.profile_pdf = profile_pdf;
    }
    public String getCgp_status() {
        return cgp_status;
    }
}
