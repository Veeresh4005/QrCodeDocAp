package com.example.qr_id_student_information;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Date;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class vehicle_information extends AppCompatActivity
{

    TextView textView1,textView2,textView3,textView4,textView5,textView6,textView7,textView8,textView9,textView10;
    TextView textView1d,textView2d,textView3d,textView4d,textView5d,textView6d,textView7d,textView8d,textView9d,textView10d;
    TextView textView1e,textView2e,textView3e,textView4e,textView5e,textView6e,textView7e,textView8e;

    TextView textView1i,textView2i,textView3i,textView4i,textView5i,textView6i,textView7i,textView8i;

    SharedPrefHandler sharedPrefHandler;
    String string_qe;
    String todayString;

    String string_driving_valid,string_documnet_valid,string_emission_valid,string_insurence_valid;

    Button button_msg;

    int dr_a,dr_b,do_a,do_b,em_a,em_b,in_a,in_b;
    List<vehicleconst> productList1;

Date date_todays;
    Date date_dr,date_do,date_em,date_in;
    Date todayDate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vehicle_information);
        sharedPrefHandler = new SharedPrefHandler(this);

        string_qe = sharedPrefHandler.getSharedPreferences("qrcode_vehicle");
        Toast.makeText(this, "" + string_qe, Toast.LENGTH_SHORT).show();


        textView1 = (TextView) findViewById(R.id.TextViewCard1v);
        textView2 = (TextView) findViewById(R.id.TextViewCard2v);
        textView3 = (TextView) findViewById(R.id.TextViewCard3v);
        textView4 = (TextView) findViewById(R.id.TextViewCard4v);
        textView5 = (TextView) findViewById(R.id.TextViewCard5v);
        textView6 = (TextView) findViewById(R.id.TextViewCard6v);
        textView7 = (TextView) findViewById(R.id.TextViewCard7v);
        textView8 = (TextView) findViewById(R.id.TextViewCard8v);
        textView9 = (TextView) findViewById(R.id.TextViewCard9v);



        getStudent(string_qe);







    }



    // Drivining


    private void getStudent(final String string_qe)
    {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        Api api = retrofit.create(Api.class);

        Call<List<vehicleconst>> call = api.getVehicle_information(string_qe);

        call.enqueue(new Callback<List<vehicleconst>>() {
            @Override
            public void onResponse(Call<List<vehicleconst>> call, Response<List<vehicleconst>> response) {
                productList1 = response.body();

                Boolean isSuccess = false;
                if(response.body() != null) {
                    isSuccess = true;
                }

                if(isSuccess) {
                    textView1.setText("Vehicle Number : "+productList1.get(0).getVno());
                    textView2.setText("Vehicle Name : "+productList1.get(0).getVname());
                    textView3.setText("Mobile Number : "+productList1.get(0).getMno());
                    textView4.setText("Owner Name : "+productList1.get(0).getOname());
                    textView5.setText("Address  : "+productList1.get(0).getAddress());
                    textView6.setText("Model Number : "+productList1.get(0).getModelNo());
                    textView7.setText("Vehicle Color : "+productList1.get(0).getVcolor());




                } else {

                }
            }

            @Override
            public void onFailure(Call<List<vehicleconst>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


}
