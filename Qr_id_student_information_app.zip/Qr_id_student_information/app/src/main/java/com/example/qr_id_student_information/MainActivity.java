package com.example.qr_id_student_information;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

public class MainActivity extends AppCompatActivity
{

    CardView cardView_one,cardView_two,cardView_three,cardView_four;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        cardView_one=(CardView)findViewById(R.id.r1);
        cardView_two=(CardView)findViewById(R.id.r2);
        cardView_three=(CardView)findViewById(R.id.r3);
        cardView_four=(CardView)findViewById(R.id.r4);


        cardView_one.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Intent intent=new Intent(getApplication(),Scan_code.class);
                startActivity(intent);

            }
        });



        cardView_two.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplication(),Feedback.class);
                startActivity(intent);
            }
        });


        cardView_three.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplication(),Scan_code_vehicle.class);
                startActivity(intent);
            }
        });




        cardView_four.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplication(),About_app.class);
                startActivity(intent);
            }
        });




    }
}
