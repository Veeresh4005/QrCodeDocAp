package com.example.qr_id_student_information;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Query;

public interface Api
{
    // String BASE_URL = "https://simplifiedcoding.net/demos/";
    // String BASE_URL = "https://fanciful-petroleum.000webhostapp.com/api/";
    String BASE_URL = "http://192.168.80.47/QR_code_student_vehicle/staff/";

    @GET("user/login") //i.e https://fanciful-petroleum.000webhostapp.com/api/user/login?mobileNo=9035292096&password=123456
    Call<IsExist> doLogin(@Query("mobileNo") String username, @Query("password") String password);

    @GET("get_student_info.php")
    Call<List<studentconst>> getStudent_information(@Query("f1") String string_qe);


    @GET("get_vehicle_info.php")
    Call<List<vehicleconst>> getVehicle_information(@Query("f1") String string_qe);


}
