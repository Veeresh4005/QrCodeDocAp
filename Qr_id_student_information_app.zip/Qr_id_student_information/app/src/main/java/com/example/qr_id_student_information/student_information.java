package com.example.qr_id_student_information;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.StrictMode;
import android.os.Bundle;
import android.telephony.gsm.SmsManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import androidx.appcompat.app.AppCompatActivity;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class student_information extends AppCompatActivity
{

    TextView textView1,textView2,textView3,textView4,textView5,textView6,textView7,textView8,textView9,textView10;
    TextView textView1d,textView2d,textView3d,textView4d,textView5d,textView6d,textView7d,textView8d,textView9d,textView10d;
    TextView textView1e,textView2e,textView3e,textView4e,textView5e,textView6e,textView7e,textView8e;

    TextView textView1i,textView2i,textView3i,textView4i,textView5i,textView6i,textView7i,textView8i;

    SharedPrefHandler sharedPrefHandler;
    String string_qe;
    String todayString;

    String string_driving_valid,string_documnet_valid,string_emission_valid,string_insurence_valid;

    Button button_msg;

    int dr_a,dr_b,do_a,do_b,em_a,em_b,in_a,in_b;
    List<studentconst> productList1;

Date date_todays;
    Date date_dr,date_do,date_em,date_in;
    Date todayDate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student_information);
        sharedPrefHandler = new SharedPrefHandler(this);

        string_qe = sharedPrefHandler.getSharedPreferences("qrcode");
        Toast.makeText(this, "" + string_qe, Toast.LENGTH_SHORT).show();


        textView1 = (TextView) findViewById(R.id.TextViewCard1);
        textView2 = (TextView) findViewById(R.id.TextViewCard2);
        textView3 = (TextView) findViewById(R.id.TextViewCard3);
        textView4 = (TextView) findViewById(R.id.TextViewCard4);
        textView5 = (TextView) findViewById(R.id.TextViewCard5);
        textView6 = (TextView) findViewById(R.id.TextViewCard6);
        textView7 = (TextView) findViewById(R.id.TextViewCard7);
        textView8 = (TextView) findViewById(R.id.TextViewCard8);
        textView9 = (TextView) findViewById(R.id.TextViewCard9);
        textView10 = (TextView) findViewById(R.id.TextViewCard10);



        getStudent(string_qe);


    textView9.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            String str_url="http://192.168.80.47/QR_code_student_vehicle/admin/"+textView9.getText().toString();

            Intent intent = new Intent(Intent.ACTION_VIEW);
            intent.setData(Uri.parse(str_url));
            intent.setPackage("com.android.chrome");

            // Verify that Chrome is available
            if (intent.resolveActivity(getPackageManager()) != null) {
                startActivity(intent);
            } else {
                // Fallback to any browser if Chrome isn't available
                Intent fallbackIntent = new Intent(Intent.ACTION_VIEW, Uri.parse(str_url));
                startActivity(fallbackIntent);
            }
        }
    });




    }



    // Drivining


    private void getStudent(final String string_qe)
    {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(Api.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create()) //Here we are using the GsonConverterFactory to directly convert json data to object
                .build();

        Api api = retrofit.create(Api.class);

        Call<List<studentconst>> call = api.getStudent_information(string_qe);

        call.enqueue(new Callback<List<studentconst>>() {
            @Override
            public void onResponse(Call<List<studentconst>> call, Response<List<studentconst>> response) {
                productList1 = response.body();

                Boolean isSuccess = false;
                if(response.body() != null) {
                    isSuccess = true;
                }

                if(isSuccess) {
                    textView1.setText("Usn Number : "+productList1.get(0).getUsn());
                    textView2.setText("Student Name : "+productList1.get(0).getName());
                    textView3.setText("Mobile Number : "+productList1.get(0).getMno());
                    textView4.setText("Email Address : "+productList1.get(0).getEmail());
                    textView5.setText("Semester  : "+productList1.get(0).getSemester());
                    textView6.setText("Department : "+productList1.get(0).getDepartment());
                    textView7.setText("Parents Mobile Number : "+productList1.get(0).getParents_mno());
                    textView8.setText("Postal Address : "+productList1.get(0).getPostal_address());
                    textView9.setText(productList1.get(0).getProfile_pdf());
                    textView10.setText("CGP and Placement Status : "+productList1.get(0).getCgp_status());




                } else {

                }
            }

            @Override
            public void onFailure(Call<List<studentconst>> call, Throwable t) {
                Toast.makeText(getApplicationContext(), t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }


}
