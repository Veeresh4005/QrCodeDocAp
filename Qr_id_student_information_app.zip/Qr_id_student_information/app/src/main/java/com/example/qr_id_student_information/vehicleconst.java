package com.example.qr_id_student_information;

public class vehicleconst {

    private String vno;
    private String vname;
    private String oname;
    private String mno;
    private String address;
    private String modelNo;
    private String vcolor;

    public vehicleconst(String vno, String vname, String oname, String mno, String address, String modelNo, String vcolor) {
        this.vno = vno;
        this.vname = vname;
        this.oname = oname;
        this.mno = mno;
        this.address = address;
        this.modelNo = modelNo;
        this.vcolor = vcolor;
    }

    public String getVno() {
        return vno;
    }

    public void setVno(String vno) {
        this.vno = vno;
    }

    public String getVname() {
        return vname;
    }

    public void setVname(String vname) {
        this.vname = vname;
    }

    public String getOname() {
        return oname;
    }

    public void setOname(String oname) {
        this.oname = oname;
    }

    public String getMno() {
        return mno;
    }

    public void setMno(String mno) {
        this.mno = mno;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getModelNo() {
        return modelNo;
    }

    public void setModelNo(String modelNo) {
        this.modelNo = modelNo;
    }

    public String getVcolor() {
        return vcolor;
    }

    public void setVcolor(String vcolor) {
        this.vcolor = vcolor;
    }
}
