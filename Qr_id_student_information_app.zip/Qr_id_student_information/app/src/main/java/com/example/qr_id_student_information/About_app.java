package com.example.qr_id_student_information;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;


public class About_app extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_app);
    }
}
