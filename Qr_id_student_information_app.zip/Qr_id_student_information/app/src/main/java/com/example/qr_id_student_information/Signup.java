package com.example.qr_id_student_information;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Signup extends AppCompatActivity {
    EditText etName, etEmail, etMno, etPassword;
    Button btnSignup;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etMno = findViewById(R.id.etMno);
        etPassword = findViewById(R.id.etPassword);
        btnSignup = findViewById(R.id.btnSignup);

        db = new DatabaseHelper(this);

        btnSignup.setOnClickListener(v -> {
            String name = etName.getText().toString();
            String email = etEmail.getText().toString();
            String mno = etMno.getText().toString();
            String password = etPassword.getText().toString();

            if (name.isEmpty() || email.isEmpty() || mno.isEmpty() || password.isEmpty()) {
                Toast.makeText(Signup.this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            } else {
                boolean isInserted = db.insertUser(name, email, mno, password);
                if (isInserted) {
                    Toast.makeText(Signup.this, "Signup Successful", Toast.LENGTH_SHORT).show();
                    startActivity(new Intent(Signup.this, Login_page.class));
                } else {
                    Toast.makeText(Signup.this, "Signup Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
