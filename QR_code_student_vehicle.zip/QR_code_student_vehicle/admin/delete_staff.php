<?php
include('dbconnect.php');

$get_id=$_GET['id'];
$query=mysqli_query($conn,"DELETE FROM staff WHERE staff_id='$get_id' ");

if($query) {
 echo "<script>alert('Staff member deleted successfully.'); window.location.href='view_staff.php';</script>";
  
} else {
  echo "Error deleting staff member.";
}
 

?>