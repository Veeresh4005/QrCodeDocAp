<?php

$conn=mysqli_connect('localhost','root','','qr_code_student_information');

?>