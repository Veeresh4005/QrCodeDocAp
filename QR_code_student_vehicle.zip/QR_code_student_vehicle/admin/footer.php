<footer class="main-footer">
  <div align="center">
    <strong>Copyright &copy; 2024 <a href="">QR ID INSTANT STUDENT INFORMATION ACCESS SYSTEM.</a>.</strong> All rights
    reserved.
    </div>
  </footer>
  
  
  
