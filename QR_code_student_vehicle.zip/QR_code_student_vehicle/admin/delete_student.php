<?php
include('dbconnect.php');

$get_id=$_GET['usn'];
$query=mysqli_query($conn,"DELETE FROM student WHERE usn='$get_id' ");

if($query) {
 echo "<script>alert('Student   deleted successfully.'); window.location.href='view_student.php';</script>";
  
} else {
  echo "Error deleting staff member.";
}
 

?>