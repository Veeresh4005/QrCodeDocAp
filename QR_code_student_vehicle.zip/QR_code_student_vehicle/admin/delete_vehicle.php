<?php
include('dbconnect.php');

$get_id=$_GET['id'];
$query=mysqli_query($conn,"DELETE FROM vehicle WHERE vno='$get_id' ");

if($query) {
 echo "<script>alert('Vehicle   deleted successfully.'); window.location.href='view_vehicle.php';</script>";
  
} else {
  echo "Error deleting staff member.";
}
 

?>