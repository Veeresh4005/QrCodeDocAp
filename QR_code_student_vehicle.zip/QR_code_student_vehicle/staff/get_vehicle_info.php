<?php

$conn=mysqli_connect('localhost','root','','qr_code_student_information'); 
 
$output=array();
$v1=$_REQUEST['f1'];
$result=mysqli_query($conn,"select * from vehicle WHERE vno='$v1'");

$cnt=0;

while($r=mysqli_fetch_array($result))
{
    $cnt=1;
    $output[]=array("vno"=>$r["vno"],
                    "vname"=>$r["vname"],
                    "oname"=>$r["oname"],
                    "mno"=>$r["mno"],
                    "address"=>$r["address"],
                    "modelNo"=>$r["modelNo"],
                    "vcolor"=>$r["vcolor"]);       
}

  
$flag["code"]="0";

if($cnt>0)
{
    $flag["code"]="1";
    
    print(json_encode($output));
}
else
{   
    printf(json_encode("Error"));

} 

  

?>