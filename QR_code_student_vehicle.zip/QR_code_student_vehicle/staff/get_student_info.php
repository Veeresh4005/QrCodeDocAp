<?php

$conn=mysqli_connect('localhost','root','','qr_code_student_information'); 
 
$output=array();
$v1=$_REQUEST['f1'];
$result=mysqli_query($conn,"select * from student WHERE usn='$v1'");

$cnt=0;

while($r=mysqli_fetch_array($result))
{
    $cnt=1;
    $output[]=array("usn"=>$r["usn"],
                    "name"=>$r["name"],
                    "email"=>$r["email"],
                    "mno"=>$r["mno"],
                    "semester"=>$r["semester"],
                    "department"=>$r["department"],
                    "postal_address"=>$r["postal_address"],
                    "parents_mno"=>$r["parents_mno"],
                    "profile_pdf"=>$r["profile_pdf"],"cgp_status"=>$r["cgp_status"]);       
}

  
$flag["code"]="0";

if($cnt>0)
{
    $flag["code"]="1";
    
    print(json_encode($output));
}
else
{   
    printf(json_encode("Error"));

} 

  

?>